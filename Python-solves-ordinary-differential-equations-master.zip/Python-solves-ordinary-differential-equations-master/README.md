# Python-solves-ordinary-differential-equations

这里对使用python求解常微分方程提供两种思路:

一种是自己编程实现欧拉法，改进欧拉法或者四阶龙格库塔，这样有助于理解上述三种数值计算方法的原理；

一种是调用python已有的库，不再重复造轮子

同时也有一些其他方法的实现
